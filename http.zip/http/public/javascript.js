document.addEventListener("DOMContentLoaded", function () {

    async function fetchNavbarInfo() {

        const response = await fetch("/cgi-bin/get-info-navbar");
        const res = await response.json();

        if (res.status == "Success") {
            document.getElementById("location-config-nav").textContent = res.data.location || "--";
            document.getElementById("client-config-nav").textContent = res.data.client || "--";
            document.getElementById("wan-ip-config-nav").textContent = res.data.wanIp || "--";
            document.getElementById("lan-ip-config-nav").textContent = res.data.lanIp || "--";
            document.getElementById("id-config-nav").textContent = res.data.deviceId || "--";
            document.getElementById("version-config-nav").textContent = res.data.version || "--";
        } else {
            window.alert("Erro: " + res.msg);
        }

    }

    async function fetchUptime() {

        const response = await fetch("/cgi-bin/get-uptime");
        const res = await response.json();

        if (res.status == "Success") {
            var uptimeElement = document.getElementById("uptime");
            var dias = res.data.dias;
            var horas = res.data.horas;
            var minutos = res.data.minutos;
            uptimeElement.textContent = `${dias}d ${horas}h ${minutos}m`;
        } else {
            window.alert("Erro: " + res.msg);
        }
    }

    async function fetchTraffic() {

        const resopnse = await fetch("/cgi-bin/get-traffic");
        const res = await resopnse.json();

        if (res.status == "Success") {
            document.getElementById("rx-traffic").textContent = res.data.rx_mb + " MB";
            document.getElementById("tx-traffic").textContent = res.data.tx_mb + " MB";
        } else {
            window.alert("Erro: " + res.msg);
        }
    }

    async function fetchLogs() {
        const response = await fetch("/cgi-bin/get-log-watchdog");
        const res = await response.json();

        if (res.status == "Success") {
            const logsBody = document.getElementById("logs-body");
            logsBody.innerHTML = "";

            res.logs.forEach(logLine => {
                const parts = logLine.split(" - ");
                const timestamp = parts[0] || "--";
                const message = parts[1] || logLine;

                const tr = document.createElement("tr");
                tr.innerHTML = `
                    <td class="font-mono small">${timestamp}</td>
                    <td><span class="badge bg-info bg-opacity-10 text-info border border-info border-opacity-25 small">INFO</span></td>
                    <td class="text-muted small">WATCHDOG</td>
                    <td class="text-light small">${message}</td>
                `;
                logsBody.appendChild(tr);
            });
        } else {
            window.alert("Erro: " + res.msg);

        }
    }

    async function fetchStatusVpn() {

        const response = await fetch("/cgi-bin/get-status-vpn");
        const res = await response.json();

        var connectionBagdeElement = document.getElementById("connection-badge");
        var connectionDotElement = document.getElementById("connection-dot");
        var connectionTextElement = document.getElementById("connection-text");

        if (res.status == "Success") {

            connectionBagdeElement.classList.replace('bg-danger', 'bg-success');
            connectionBagdeElement.classList.replace('text-danger', 'text-success');
            connectionBagdeElement.classList.replace('border-danger', 'border-success');

            connectionDotElement.classList.replace('status-offline', 'status-online');
            
            connectionTextElement.textContent = "ONLINE";
        } else {

            connectionBagdeElement.classList.replace('bg-success', 'bg-danger');
            connectionBagdeElement.classList.replace('text-success', 'text-danger');
            connectionBagdeElement.classList.replace('border-success', 'border-danger');

            connectionDotElement.classList.replace('status-online', 'status-offline');

            connectionTextElement.textContent = "OFFLINE";
        }
    }

    fetchStatusVpn();
    fetchLogs();
    fetchNavbarInfo();
    fetchUptime();
    fetchTraffic();
    setInterval(fetchUptime, 60000);
});